using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Diagnostics;

namespace TechDaysRoslynDemo
{
    [DiagnosticAnalyzer(LanguageNames.CSharp)]
    public class TechDaysRoslynDemoAnalyzer : DiagnosticAnalyzer
    {
        public const string DiagnosticId = "TechDaysRoslynDemo";

        private static readonly LocalizableString Title = new LocalizableResourceString(nameof(Resources.AnalyzerTitle), Resources.ResourceManager, typeof(Resources));
        private static readonly LocalizableString MessageFormat = new LocalizableResourceString(nameof(Resources.AnalyzerMessageFormat), Resources.ResourceManager, typeof(Resources));
        private static readonly LocalizableString Description = new LocalizableResourceString(nameof(Resources.AnalyzerDescription), Resources.ResourceManager, typeof(Resources));
        private const string Category = "Usage";

        private static DiagnosticDescriptor Rule = new DiagnosticDescriptor(DiagnosticId, Title, MessageFormat, Category, DiagnosticSeverity.Warning, isEnabledByDefault: true, description: Description);

        public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics { get { return ImmutableArray.Create(Rule); } }

        public override void Initialize(AnalysisContext context)
        {
            context.RegisterSyntaxNodeAction(AnalyzeNode, SyntaxKind.ForStatement);
        }

        private void AnalyzeNode(SyntaxNodeAnalysisContext context)
        {
            var fss = (ForStatementSyntax)context.Node;

            var sem = context.SemanticModel;

            var variables = fss.Declaration.Variables;

            var symbols = new HashSet<ISymbol>(variables.Select(variable => sem.GetDeclaredSymbol(variable)));

            var johnny = new Johnny(context, sem, symbols);

            johnny.Visit(fss.Statement);
        }

        class Johnny : CSharpSyntaxWalker
        {
            private readonly SyntaxNodeAnalysisContext _context;
            private readonly SemanticModel _model;
            private readonly HashSet<ISymbol> _symbols;

            public Johnny(SyntaxNodeAnalysisContext context, SemanticModel model, HashSet<ISymbol> symbols)
            {
                _context = context;
                _model = model;
                _symbols = symbols;
            }

            private bool _inLambda;

            public override void VisitParenthesizedLambdaExpression(ParenthesizedLambdaExpressionSyntax node)
            {
                var wasInLambda = _inLambda;
                _inLambda = true;

                base.VisitParenthesizedLambdaExpression(node);

                _inLambda = wasInLambda;
            }

            public override void VisitSimpleLambdaExpression(SimpleLambdaExpressionSyntax node)
            {
                var wasInLambda = _inLambda;
                _inLambda = true;

                base.VisitSimpleLambdaExpression(node);

                _inLambda = wasInLambda;
            }

            public override void VisitAnonymousMethodExpression(AnonymousMethodExpressionSyntax node)
            {
                var wasInLambda = _inLambda;
                _inLambda = true;

                base.VisitAnonymousMethodExpression(node);

                _inLambda = wasInLambda;
            }

            public override void VisitIdentifierName(IdentifierNameSyntax node)
            {
                if (_inLambda)
                {
                    var symbol = _model.GetSymbolInfo(node);
                    if (symbol.Symbol != null && _symbols.Contains(symbol.Symbol))
                    {
                        var diagnostic = Diagnostic.Create(Rule, node.GetLocation(), node.Identifier.Text);

                        _context.ReportDiagnostic(diagnostic);
                    }
                }
                
                base.VisitIdentifierName(node);
            }
        }
    }
}
