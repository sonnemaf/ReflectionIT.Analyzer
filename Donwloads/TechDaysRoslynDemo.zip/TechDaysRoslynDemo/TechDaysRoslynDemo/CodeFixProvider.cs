﻿using System.Collections.Immutable;
using System.Composition;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CodeFixes;
using Microsoft.CodeAnalysis.CodeActions;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Formatting;

namespace TechDaysRoslynDemo
{
    [ExportCodeFixProvider(LanguageNames.CSharp, Name = nameof(TechDaysRoslynDemoCodeFixProvider)), Shared]
    public class TechDaysRoslynDemoCodeFixProvider : CodeFixProvider
    {
        private const string title = "Fix your closures!";

        public sealed override ImmutableArray<string> FixableDiagnosticIds
        {
            get { return ImmutableArray.Create(TechDaysRoslynDemoAnalyzer.DiagnosticId); }
        }

        public sealed override FixAllProvider GetFixAllProvider()
        {
            // See https://github.com/dotnet/roslyn/blob/master/docs/analyzers/FixAllProvider.md for more information on Fix All Providers
            return WellKnownFixAllProviders.BatchFixer;
        }

        public sealed override async Task RegisterCodeFixesAsync(CodeFixContext context)
        {
            var root = await context.Document.GetSyntaxRootAsync(context.CancellationToken).ConfigureAwait(false);

            var diagnostic = context.Diagnostics.First();
            var diagnosticSpan = diagnostic.Location.SourceSpan;

            var identifier = (IdentifierNameSyntax)root.FindToken(diagnosticSpan.Start).Parent;

            context.RegisterCodeFix(
                CodeAction.Create(
                    title: title,
                    createChangedDocument: c => FixClosuresAsync(context.Document, identifier, c),
                    equivalenceKey: title),
                diagnostic);
        }

        private async Task<Document> FixClosuresAsync(Document document, IdentifierNameSyntax identifier, CancellationToken cancellationToken)
        {
            var sem = await document.GetSemanticModelAsync();

            var symbol = sem.GetSymbolInfo(identifier).Symbol;

            var forStatement = identifier.AncestorsAndSelf().OfType<ForStatementSyntax>().First(fss => fss.Declaration.Variables.Any(var => sem.GetDeclaredSymbol(var) == symbol));

            var newIdentifier = SyntaxFactory.IdentifierName(identifier.Identifier.Text + "Closure");

            var newStatement = (StatementSyntax)new Replacer(symbol, sem, newIdentifier).Visit(forStatement.Statement);

            var body = newStatement;
            if (!body.IsKind(SyntaxKind.Block))
            {
                body = SyntaxFactory.Block(body);
            }

            var blockBody = (BlockSyntax)body;

            var closureVariableInitializer = SyntaxFactory
                .LocalDeclarationStatement(SyntaxFactory
                    .VariableDeclaration(SyntaxFactory.IdentifierName("var"))
                    .WithVariables(SyntaxFactory
                        .SingletonSeparatedList(SyntaxFactory
                            .VariableDeclarator(newIdentifier.Identifier)
                            .WithInitializer(SyntaxFactory
                                .EqualsValueClause(identifier)
                            )
                        )
                    )
                )
                .WithAdditionalAnnotations(Formatter.Annotation);

            var newBlockBody = SyntaxFactory.Block(new[] { closureVariableInitializer }
                .Concat(blockBody.Statements));

            var newForStatement = forStatement.WithStatement(newBlockBody);

            var root = await document.GetSyntaxRootAsync();
            var newRoot = root.ReplaceNode(forStatement, newForStatement);

            var newDocument = document.WithSyntaxRoot(newRoot);
            return newDocument;
        }

        class Replacer : CSharpSyntaxRewriter
        {
            private readonly SemanticModel _model;
            private readonly SyntaxNode _newIdentifier;
            private readonly ISymbol _symbol;

            public Replacer(ISymbol symbol, SemanticModel model, SyntaxNode newIdentifier)
            {
                _symbol = symbol;
                _model = model;
                _newIdentifier = newIdentifier;
            }

            public override SyntaxNode VisitIdentifierName(IdentifierNameSyntax node)
            {
                var symbol = _model.GetSymbolInfo(node);
                if (symbol.Symbol == _symbol)
                {
                    return _newIdentifier;
                }

                return base.VisitIdentifierName(node);
            }
        }
    }
}